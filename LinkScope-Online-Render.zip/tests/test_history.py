import io
import sys
from pathlib import Path
from unittest.mock import Mock, patch
from openpyxl import load_workbook
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import app
from history_api import normalize_history


def example():
    return {'status':'success','normalized':True,'changesOnly':True,
        'range':{'from':'2026-07-01','to':'2026-10-09','days':90},
        'limits':{'truncated':False},'items':[{'itemId':123,'status':'success',
        'price':{'points':[{'date':'2026-09-20','price':100000},{'date':'2026-09-21','price':0}], 'stats':{'min':0,'max':100000,'dayCount':2}},
        'commission':{'points':[{'date':'2026-09-20','sellerRate':0.1,'shopeeRate':0.035,'commission':13500,'priceSnapshot':100000},{'date':'2026-09-21','sellerRatePercent':0,'shopeeRatePercent':0,'totalRatePercent':0,'suspect':True,'recorded':{'totalRatePercent':2}}], 'stats':{'maxTotalRatePercent':13.5,'dayCount':2}}}]}


def test_history_auth_limits():
    c=app.test_client()
    for body in [{'itemIds':['123']},{'apiKey':'key','itemIds':['1']*51},{'apiKey':'key','itemIds':['1'],'days':731},{'apiKey':'key','itemIds':['x']},{'apiKey':'key','itemIds':['1'],'base_rate':-1}]:
        assert c.post('/api/history',json=body).status_code==400


def test_history_mapping_tier_and_flags():
    data=example();data['limits']['truncated']=True
    upstream=Mock(status_code=200);upstream.json.return_value=data
    with patch('history_api.requests.post',return_value=upstream) as call:
        r=app.test_client().post('/api/history',json={'apiKey':'secret','itemIds':['456','123'],'days':90,'base_rate':3.5,'cap':40000})
        assert r.status_code==200
        payload=call.call_args.kwargs['json']
        assert payload['type']=='both' and payload['changes_only']==1 and payload['base_rate']==0.035 and payload['cap']==40000
        assert call.call_args.kwargs['headers']['X-API-Key']=='secret'
        assert call.call_args.kwargs['allow_redirects'] is False
        assert r.json['results'][0]['status']=='error'
        h=r.json['results'][1]
        assert h['normalized'] and h['truncated']
        assert h['commissions'][0]['totalRatePercent']==13.5
        assert h['commissions'][1]['totalRatePercent']==0 and h['commissions'][1]['suspect']
        assert h['prices'][1]['price']==0
        assert any('cắt bớt' in w for w in h['warnings'])


def test_history_empty_missing_raw():
    data=example();data['normalized']=False
    h=normalize_history({'status':'no_data'},'123',data,{'days':90,'base_rate':None,'cap':None})
    assert h['prices']==[] and h['commissions']==[]
    assert not h['normalized'] and any('biến động giả' in w for w in h['warnings'])
    h=normalize_history({'status':'success','commission':{'points':[{'date':'2026-09-20','commission':10,'priceSnapshot':100}]}},'123',data,{'days':90,'base_rate':None,'cap':None})
    assert h['commissions'][0]['totalRatePercent'] is None


def test_history_failure_and_rate_limit():
    c=app.test_client()
    for code in (401,403,429,500):
        response=Mock(status_code=code,headers={'Retry-After':'90'})
        with patch('history_api.requests.post',return_value=response):
            r=c.post('/api/history',json={'apiKey':'secret','itemIds':['123']})
            assert r.status_code==(502 if code==500 else code)
            if code==429: assert r.json['retryAfter']==90


def test_history_export():
    data=example();h=normalize_history(data['items'][0],'123',data,{'days':90,'base_rate':3.5,'cap':40000});h['name']='=HYPERLINK("bad")'
    r=app.test_client().post('/api/history/export',json={'histories':[h],'demo':True})
    assert r.status_code==200
    wb=load_workbook(io.BytesIO(r.data))
    assert wb['Tổng quan']['B2'].value.startswith("'")
    assert wb['Lịch sử giá']['C3'].value==0
    assert wb['Lịch sử hoa hồng']['E3'].value==0 and wb['Lịch sử hoa hồng']['H3'].value is True
    assert wb['Lịch sử hoa hồng']['K3'].value==2
    assert 'GIẢ LẬP' in wb['Lưu ý']['A1'].value
