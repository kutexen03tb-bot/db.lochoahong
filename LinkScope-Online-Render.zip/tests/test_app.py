import io
import sys
from pathlib import Path
from unittest.mock import patch, Mock
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import app, extract_id, normalize
from openpyxl import load_workbook, Workbook


def test_extract():
    for value in ['https://shopee.vn/product/123/456?x=1','https://shopee.vn/abc-i.123.456','shopee.vn/opaanlp/123/456','https://shopee.vn/a?itemId=456','456']:
        assert extract_id(value) == ('456', None)
    for value in ['https://evil.example/product/123/456','https://shopee.vn.evil.example/product/123/456','https://s.shopee.vn/abc','javascript:alert(1)','https://u:p@shopee.vn/product/123/456']:
        assert extract_id(value)[0] is None


def test_analyze():
    c=app.test_client()
    r=c.post('/api/analyze',json={'values':['https://shopee.vn/product/123/456','456','bad','https://s.shopee.vn/abc','789']}).json
    assert len(r['items'])==2 and r['duplicates']==1 and len(r['errors'])==2


def test_unknown_rate_and_fallback():
    r=normalize({'status':'success','productInfo':{'price':100,'commission':10}},'1','1')
    assert r['totalRate'] is None and r['effectiveRate']==10 and r['status']=='incomplete'
    r=normalize({'status':'success','dataSource':'fallback','productInfo':{'price':0,'commission':0}},'1','1')
    assert r['price'] is None and r['commission'] is None
    r=normalize({'status':'success','productInfo':{'price':100,'sellerRate':0,'shopeeRate':0,'commission':0}},'1','1')
    assert r['totalRate']==0 and r['status']=='success' and r['effectiveRate']==0
    r=normalize({'status':'stale','reason':'commission_unverified','productInfo':{'price':100,'totalRatePercent':10,'commission':10}},'1','1')
    assert r['totalRate'] is None and r['commission'] is None


def test_batch_mapping_and_auth():
    c=app.test_client()
    assert c.post('/api/check',json={'items':[{'itemId':'1'}]}).status_code==400
    response=Mock(status_code=200,ok=True)
    response.json.return_value={'status':'success','products':[{'itemId':'2','status':'success','productInfo':{'price':200,'totalRatePercent':5}},{'itemId':'1','status':'success','productInfo':{'price':100,'totalRatePercent':8}}]}
    with patch('app.requests.post',return_value=response) as p:
        r=c.post('/api/check',json={'apiKey':'test-key','items':[{'itemId':'1'},{'itemId':'2'},{'itemId':'3'}],'base_rate':0.5}).json
        assert r['results'][0]['price']==100 and r['results'][1]['price']==200
        assert r['results'][2]['status']=='error'
        assert p.call_args.kwargs['headers']['X-API-Key']=='test-key'
        assert p.call_args.kwargs['json']['base_rate']==0.005
        assert p.call_args.kwargs['allow_redirects'] is False
    response=Mock(status_code=429,headers={'Retry-After':'120'})
    with patch('app.requests.post',return_value=response):
        r=c.post('/api/check',json={'apiKey':'k','items':[{'itemId':'1'}]})
        assert r.status_code==429 and r.json['retryAfter']==120


def test_import_export():
    c=app.test_client()
    f=io.BytesIO('Link;Ghi chú\nhttps://shopee.vn/product/1/2;abc'.encode())
    r=c.post('/api/import',data={'file':(f,'links.csv')}).json
    assert r['rows'][1][0]=='https://shopee.vn/product/1/2'
    wb=Workbook();ws=wb.active;ws.append(['Link']);ws.append(['Mở sản phẩm']);ws['A2'].hyperlink='https://shopee.vn/product/1/2'
    b=io.BytesIO();wb.save(b);b.seek(0)
    r=c.post('/api/import',data={'file':(b,'links.xlsx')}).json
    assert r['rows'][1][0]=='https://shopee.vn/product/1/2'
    r=c.post('/api/export',json={'format':'xlsx','rows':[{'itemId':'123','name':'=HYPERLINK("evil")','price':120000,'totalRate':0}]})
    assert r.status_code==200
    wb=load_workbook(io.BytesIO(r.data));ws=wb.worksheets[0]
    assert ws['C2'].value.startswith("'") and ws['C2'].data_type!='f'
    assert ws['E2'].value==120000 and ws['H2'].value==0
    assert ws.freeze_panes=='E2'
    r=c.post('/api/export',json={'format':'csv','rows':[{'name':'=cmd'}]})
    assert "'=cmd" in r.data.decode('utf-8-sig')
