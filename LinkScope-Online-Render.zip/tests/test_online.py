from pathlib import Path
import sys
import re
import pytest
from flask import Flask, jsonify
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from online_security import install_security

PASSWORD = 'this-is-a-test-password-only'


def make_app():
    app = Flask('online_test', template_folder=str(Path(__file__).resolve().parents[1] / 'templates'))
    app.config['TESTING'] = True
    app.get('/', endpoint='home')(lambda: 'PRIVATE WORKSPACE')
    app.post('/api/check', endpoint='check')(lambda: jsonify(results=[]))
    app.post('/api/history', endpoint='history')(lambda: jsonify(results=[]))
    install_security(app, PASSWORD, 'test-session-secret-is-at-least-32-characters-long')
    return app


def login(client):
    r = client.get('/login', base_url='https://example.test')
    csrf = re.search(r'name="csrf_token" value="([^"]+)"', r.text)[1]
    r = client.post('/login', data={'csrf_token': csrf, 'password': PASSWORD}, base_url='https://example.test')
    assert r.status_code == 302
    with client.session_transaction(base_url='https://example.test') as s:
        token = s['csrf']
    return token


def test_fail_closed():
    with pytest.raises(RuntimeError):
        install_security(Flask('bad'), '', '')


def test_auth_csrf_and_logout():
    app = make_app(); c = app.test_client()
    assert c.get('/healthz', base_url='https://example.test').status_code == 200
    assert c.get('/', base_url='https://example.test').status_code == 302
    assert c.post('/api/check', json={}, base_url='https://example.test').status_code == 401
    r = c.get('/login', base_url='https://example.test')
    cookie = r.headers['Set-Cookie']
    assert 'Secure' in cookie and 'HttpOnly' in cookie and 'SameSite=Lax' in cookie
    assert c.post('/login', data={'password': PASSWORD}, base_url='https://example.test').status_code == 400
    token = login(c)
    r = c.get('/', base_url='https://example.test')
    assert r.status_code == 200 and 'PRIVATE' in r.text
    assert r.headers['X-Frame-Options'] == 'DENY'
    assert "frame-ancestors 'none'" in r.headers['Content-Security-Policy']
    assert c.post('/api/check', json={}, base_url='https://example.test').status_code == 403
    assert c.post('/api/check', json={}, headers={'X-CSRF-Token': 'tiếng việt'}, base_url='https://example.test').status_code == 403
    assert c.post('/api/check', json={}, headers={'X-CSRF-Token': token}, base_url='https://example.test').status_code == 200
    assert c.post('/logout', data={'csrf_token': token}, base_url='https://example.test').status_code == 302
    assert c.get('/', base_url='https://example.test').status_code == 302


def test_api_rate_limit():
    c = make_app().test_client(); token = login(c)
    for i in range(5):
        assert c.post('/api/check', json={}, headers={'X-CSRF-Token': token}, base_url='https://example.test').status_code == 200
    r = c.post('/api/check', json={}, headers={'X-CSRF-Token': token}, base_url='https://example.test')
    assert r.status_code == 429 and r.json['retryAfter'] == 60


def test_wrong_password_throttled():
    c = make_app().test_client()
    r = c.get('/login', base_url='https://example.test')
    token = re.search(r'name="csrf_token" value="([^"]+)"', r.text)[1]
    for i in range(5):
        assert c.post('/login', data={'csrf_token': token, 'password': 'wrong'}, base_url='https://example.test').status_code == 401
    assert c.post('/login', data={'csrf_token': token, 'password': 'wrong'}, base_url='https://example.test').status_code == 429
